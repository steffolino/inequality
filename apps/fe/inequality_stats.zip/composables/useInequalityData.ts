type TidyRow = { year:number; region:string; value:number; [k:string]: string|number|null }
type EurostatOpts = {
  dataset: string
  regions?: string[] | string        // 'DE,EU27_2020' or ['DE','EU27_2020']
  yearStart?: number
  yearEnd?: number
  dims?: Record<string, string[] | string>
}

type WidOpts = { series:string; country?:string; yearStart?:number; yearEnd?:number }

const cache = new Map<string, any>()
const normRegions = (r?: string[]|string) =>
  !r ? undefined : Array.isArray(r) ? r : r.split(',').map(s=>s.trim()).filter(Boolean)

const eurostatURL = ({ dataset, regions, yearStart, yearEnd, dims }: EurostatOpts) => {
  const base = `https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/${encodeURIComponent(dataset)}`
  const qs = new URLSearchParams()
  const rr = normRegions(regions)
  if (rr?.length) qs.set('geo', rr.join(','))
  if (yearStart || yearEnd) qs.set('time', `${yearStart ?? 2000}:${yearEnd ?? new Date().getFullYear()}`)
  if (dims) for (const [k,v] of Object.entries(dims)) {
    const arr = Array.isArray(v) ? v : String(v).split(',').map(s=>s.trim())
    if (arr.length) qs.set(k, arr.join(','))
  }
  return qs.toString() ? `${base}?${qs}` : base
}

/** JSON‑stat 2.0 → tidy rows, resilient to array/object 'value' and sparse indices */
function tidyJsonStat(json:any): TidyRow[] {
  const dim = json?.dimension, val = json?.value
  if (!dim || val==null) return []

  const ids: string[] = dim.id ?? Object.keys(dim).filter(k => !['id','size','role'].includes(k))
  const sizes: number[] = dim.size ?? ids.map(id => Object.keys(dim[id]?.category?.index ?? {}).length)

  const role = dim.role ?? {}
  const timeId = role.time?.[0] || ids.find(x=>/time/i.test(x)) || 'time'
  const geoId  = role.geo?.[0]  || ids.find(x=>/geo/i.test(x))  || 'geo'

  const codesBy: Record<string,string[]> = {}
  for (const id of ids) {
    const idx = dim[id]?.category?.index ?? {}
    const ordered = Object.entries(idx).sort((a,b)=>(a[1] as number)-(b[1] as number)).map(([code])=>code)
    codesBy[id] = ordered
  }

  const total = sizes.reduce((a,b)=>a*b,1)
  const values: (number|null)[] = Array.isArray(val)
    ? (val as (number|null)[])
    : (()=>{ const out = new Array(total).fill(null); for (const [k,v] of Object.entries(val)) out[+k] = v as number; return out })()

  const rows:TidyRow[] = []
  for (let flat=0; flat<total; flat++) {
    const v = values[flat]; if (v==null) continue
    // convert flat index → coordinates (least-significant last)
    let rem = flat
    const pos: Record<string,number> = {}
    for (let i=ids.length-1;i>=0;i--){
      pos[ids[i]] = rem % sizes[i]
      rem = Math.floor(rem / sizes[i])
    }
    const year   = Number(codesBy[timeId]?.[pos[timeId]])
    const region = String(codesBy[geoId]?.[pos[geoId]])
    if (!Number.isFinite(year) || !region) continue

    const extra:Record<string,string|number|null> = {}
    for (const id of ids) if (id!==timeId && id!==geoId) extra[id] = codesBy[id]?.[pos[id]] ?? null

    rows.push({ year, region, value: Number(v), ...extra })
  }
  rows.sort((a,b)=> (a.region<b.region? -1: a.region>b.region? 1: a.year-b.year))
  return rows
}

export function useInequalityData(){
  async function fetchEurostatTidy(opts: EurostatOpts){
    const url = eurostatURL(opts)
    if (cache.has(url)) return { url, rows: cache.get(url) as TidyRow[] }
    const res = await fetch(url, { headers:{ accept:'application/json' } })
    if (!res.ok) {
      console.error('Eurostat error', res.status, url)
      throw new Error(`Eurostat ${res.status} for ${opts.dataset}`)
    }
    const json = await res.json()
    const all = tidyJsonStat(json)
    const rr = normRegions(opts.regions); const rset = rr? new Set(rr):null
    const ys = opts.yearStart ?? -Infinity, ye = opts.yearEnd ?? Infinity
    const rows = all.filter(r => r.year>=ys && r.year<=ye && (!rset || rset.has(r.region)))
    cache.set(url, rows)
    return { url, rows }
  }

  async function fetchWidTidy(opts: WidOpts){
    const country = (opts.country ?? 'DE').slice(0,2).toUpperCase()
    const url = `https://wid.world/data/${opts.series}?areas=${country}&downloadformat=tsv`
    if (cache.has(url)) {
      const all = cache.get(url) as TidyRow[]
      const ys = opts.yearStart ?? -Infinity, ye = opts.yearEnd ?? Infinity
      return { url, rows: all.filter(r=>r.year>=ys && r.year<=ye) }
    }
    const res = await fetch(url)
    if (!res.ok){ console.error('WID error', res.status, url); throw new Error(`WID ${res.status}`) }
    const text = await res.text()
    const [h,...lines] = text.trim().split('\n')
    const idxY = h.split('\t').findIndex(x=>/year/i.test(x))
    const idxV = h.split('\t').findIndex(x=>/value/i.test(x))
    const all:TidyRow[] = lines.map(l=>{
      const c=l.split('\t'); return { year:+c[idxY], region: country, value:+c[idxV] }
    })
    cache.set(url, all)
    const ys = opts.yearStart ?? -Infinity, ye = opts.yearEnd ?? Infinity
    return { url, rows: all.filter(r=>r.year>=ys && r.year<=ye) }
  }

  return { fetchEurostatTidy, fetchWidTidy }
}