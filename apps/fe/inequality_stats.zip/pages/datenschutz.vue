<!-- pages/datenschutz.vue -->
<template>
  <section class="prose max-w-4xl mx-auto px-4 py-12">
    <h1>Datenschutzerklärung</h1>

    <h2>Allgemeine Hinweise</h2>
    <p>
      Der Schutz Ihrer persönlichen Daten ist uns wichtig. Wir behandeln Ihre personenbezogenen Daten vertraulich und entsprechend der gesetzlichen Datenschutzvorschriften (DSGVO).
    </p>

    <h2>Server-Logs</h2>
    <p>
      Unser Hosting-Provider erhebt und speichert automatisch Informationen in sogenannten Server-Log-Dateien, die Ihr Browser automatisch übermittelt: IP-Adresse, Browsertyp, Betriebssystem, Referrer-URL, Uhrzeit der Serveranfrage. Diese Daten sind nicht bestimmten Personen zuordenbar.
    </p>

    <h2>Cookies</h2>
    <p>
      Diese Website verwendet nur technisch notwendige Cookies. Tracking- oder Marketing-Cookies werden nicht eingesetzt.
    </p>

    <h2>Rechte der Nutzer:innen</h2>
    <p>
      Sie haben jederzeit das Recht auf unentgeltliche Auskunft über Ihre gespeicherten personenbezogenen Daten, deren Herkunft, Empfänger und den Zweck der Datenverarbeitung. Ebenso haben Sie ein Recht auf Berichtigung, Sperrung oder Löschung dieser Daten.
    </p>

    <h2>Kontakt zum Datenschutz</h2>
    <p>
      Bei Fragen zum Datenschutz wenden Sie sich bitte an:<br />
      info@example.com
    </p>
  </section>
</template>
