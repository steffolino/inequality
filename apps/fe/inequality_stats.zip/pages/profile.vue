<template>
  <section class="px-4 py-6 space-y-3">
    <h2 class="text-lg font-semibold">Profile</h2>
    <ul class="menu menu-sm bg-base-200 rounded-box">
      <p>placeholders</p>
      <li><button>Dark mode</button></li>
      <li><button>Export data</button></li>
    </ul>
  </section>
</template>
<script setup lang="ts">
definePageMeta({ title: 'Profile' })
</script>