<template>
  <section class="prose max-w-4xl mx-auto px-4 py-12">
    <h1>Impressum</h1>

    <p><strong>Angaben gemäß § 5 TMG</strong></p>
    <p>
      Musterverein für soziale Transparenz e.V.<br />
      Musterstraße 12<br />
      12345 Musterstadt<br />
      Deutschland
    </p>

    <h2>Vertreten durch</h2>
    <p>
      Vorstand: Max Mustermann, Erika Beispiel
    </p>

    <h2>Kontakt</h2>
    <p>
      Telefon: +49 (0) 123 456789<br />
      E-Mail: kontakt@musterverein.de
    </p>

    <h2>Registereintrag</h2>
    <p>
      Vereinsregister: Amtsgericht Musterstadt<br />
      Registernummer: VR 12345
    </p>

    <h2>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h2>
    <p>
      Max Mustermann<br />
      (Anschrift wie oben)
    </p>

    <h2>Haftungsausschluss</h2>
    <p>
      Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für
      die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind
      ausschließlich deren Betreiber verantwortlich.
    </p>
  </section>
</template>
d