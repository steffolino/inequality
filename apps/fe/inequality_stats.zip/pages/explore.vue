<template>
  <main class="mx-auto max-w-7xl px-4 py-8 space-y-8">
    <!-- Header -->
    <header class="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
      <div>
        <h1 class="text-3xl font-extrabold tracking-tight">Explore Inequality</h1>
        <p class="text-base-content/70 mt-1">Slice indicators by region and years. Every chart links to its source.</p>
      </div>
      <nav class="tabs tabs-boxed w-fit shadow-sm">
        <button class="tab" :class="tab==='overview' ? 'tab-active' : ''" @click="tab='overview'">Overview</button>
        <button class="tab" :class="tab==='playground' ? 'tab-active' : ''" @click="tab='playground'">Build‑Your‑Own</button>
        <button class="tab" :class="tab==='factcheck' ? 'tab-active' : ''" @click="tab='factcheck'">Claims & Fact‑Check</button>
      </nav>
    </header>

    <!-- Anchors -->
    <div v-show="tab==='overview'" class="flex flex-wrap gap-2 text-sm">
      <a href="#income" class="badge badge-outline">Income inequality</a>
      <a href="#poverty" class="badge badge-outline">Poverty & AROPE</a>
      <a href="#wealth" class="badge badge-outline">Wealth</a>
      <a href="#labour" class="badge badge-outline">Labour & pay gaps</a>
      <a href="#sources" class="badge badge-ghost">Sources & methods</a>
    </div>

    <!-- Overview -->
    <section v-show="tab==='overview'" class="space-y-8">
      <!-- Income -->
      <section id="income" class="rounded-2xl bg-base-100 ring-1 ring-base-300/70 shadow-sm overflow-hidden">
        <div class="px-6 pt-5 pb-3 border-b border-base-300/60">
          <h2 class="text-xl font-semibold">Income inequality</h2>
          <p class="text-xs text-base-content/60 mt-1">Eurostat EU‑SILC indicators for Germany vs EU.</p>
        </div>
        <div class="p-5 grid md:grid-cols-2 gap-5">
          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">Gini (equivalised disposable income)</h3>
                <p class="text-[11px] opacity-70">Eurostat • <code>ilc_di12</code></p>
              </div>
              <a :href="links.ilc_di12" target="_blank" class="btn btn-ghost btn-xs">Dataset</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="giniRows.length" :spec="giniSpec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">No data returned.</p>
          </article>

          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">S80/S20 income quintile ratio</h3>
                <p class="text-[11px] opacity-70">Eurostat • <code>ilc_di11</code></p>
              </div>
              <a :href="links.ilc_di11" target="_blank" class="btn btn-ghost btn-xs">Dataset</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="s8020Rows.length" :spec="s8020Spec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">No data returned.</p>
          </article>
        </div>
      </section>

      <!-- Poverty -->
      <section id="poverty" class="rounded-2xl bg-base-100 ring-1 ring-base-300/70 shadow-sm overflow-hidden">
        <div class="px-6 pt-5 pb-3 border-b border-base-300/60">
          <h2 class="text-xl font-semibold">Poverty & social exclusion</h2>
          <p class="text-xs text-base-content/60 mt-1">At‑risk‑of‑poverty (AROP) and AROPE.</p>
        </div>
        <div class="p-5 grid md:grid-cols-2 gap-5">
          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">AROP (60% of median)</h3>
                <p class="text-[11px] opacity-70">Eurostat • <code>ilc_li02</code></p>
              </div>
              <a :href="links.ilc_li02" target="_blank" class="btn btn-ghost btn-xs">Dataset</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="aropRows.length" :spec="aropSpec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">No data returned.</p>
          </article>

          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">AROPE (poverty or social exclusion)</h3>
                <p class="text-[11px] opacity-70">Eurostat • <code>ilc_peps01</code></p>
              </div>
              <a :href="links.ilc_peps01" target="_blank" class="btn btn-ghost btn-xs">Dataset</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="aropeRows.length" :spec="aropeSpec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">No data returned.</p>
          </article>
        </div>
      </section>

      <!-- Wealth -->
      <section id="wealth" class="rounded-2xl bg-base-100 ring-1 ring-base-300/70 shadow-sm overflow-hidden">
        <div class="px-6 pt-5 pb-3 border-b border-base-300/60">
          <h2 class="text-xl font-semibold">Wealth distribution</h2>
          <p class="text-xs text-base-content/60 mt-1">Top income shares from WID.</p>
        </div>
        <div class="p-5 grid md:grid-cols-2 gap-5">
          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">Top 10% income share</h3>
                <p class="text-[11px] opacity-70">WID</p>
              </div>
              <a :href="links.wid_top10" target="_blank" class="btn btn-ghost btn-xs">Data</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="widTop10Rows.length" :spec="widTop10Spec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">No data returned.</p>
          </article>

          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">Top 1% income share</h3>
                <p class="text-[11px] opacity-70">WID</p>
              </div>
              <a :href="links.wid_top1" target="_blank" class="btn btn-ghost btn-xs">Data</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="widTop1Rows.length" :spec="widTop1Spec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">No data returned.</p>
          </article>
        </div>
      </section>

      <!-- Labour -->
      <section id="labour" class="rounded-2xl bg-base-100 ring-1 ring-base-300/70 shadow-sm overflow-hidden">
        <div class="px-6 pt-5 pb-3 border-b border-base-300/60">
          <h2 class="text-xl font-semibold">Labour market & pay gaps</h2>
          <p class="text-xs text-base-content/60 mt-1">Gender pay gap (wire real series later).</p>
        </div>
        <div class="p-5">
          <article class="p-4 rounded-xl ring-1 ring-base-300/70 bg-base-50 min-h-[220px] space-y-3">
            <header class="flex items-center justify-between">
              <div>
                <h3 class="font-semibold">Gender pay gap (unadjusted, %)</h3>
                <p class="text-[11px] opacity-70">Destatis / Eurostat</p>
              </div>
              <a :href="links.gender_gap" target="_blank" class="btn btn-ghost btn-xs">Dataset</a>
            </header>
            <div v-if="loading" class="animate-pulse text-sm opacity-70">Loading…</div>
            <div v-else-if="errorMsg" class="alert alert-warning text-sm">{{ errorMsg }}</div>
            <VegaLiteEmbed v-else-if="gpgRows.length" :spec="gpgSpec" :actions="{export:true, source:false, editor:false}" />
            <p v-else class="text-sm opacity-70">Coming soon.</p>
          </article>
        </div>
      </section>

      <!-- Sources -->
      <section id="sources" class="rounded-2xl bg-base-100 ring-1 ring-base-300/70 shadow-sm p-5">
        <h2 class="text-xl font-semibold">Sources & methods</h2>
        <p class="text-xs text-base-content/60 mt-1">Dataset pages (human‑readable). Each chart’s panel also shows the exact API call used.</p>
        <ul class="list-disc ml-5 mt-3 space-y-1 text-sm">
          <li><a :href="links.ilc_di12" target="_blank" class="link link-primary">Eurostat — Gini (<code>ilc_di12</code>)</a></li>
          <li><a :href="links.ilc_di11" target="_blank" class="link link-primary">Eurostat — S80/S20 (<code>ilc_di11</code>)</a></li>
          <li><a :href="links.ilc_li02" target="_blank" class="link link-primary">Eurostat — AROP (<code>ilc_li02</code>)</a></li>
          <li><a :href="links.ilc_peps01" target="_blank" class="link link-primary">Eurostat — AROPE (<code>ilc_peps01</code>)</a></li>
          <li><a :href="links.wid_top10" target="_blank" class="link link-primary">WID — Top 10% share</a></li>
          <li><a :href="links.wid_top1" target="_blank" class="link link-primary">WID — Top 1% share</a></li>
          <li><a :href="links.gender_gap" target="_blank" class="link link-primary">Destatis — Gender pay gap</a></li>
        </ul>
      </section>
    </section>

    <!-- Playground -->
    <section v-show="tab==='playground'">
      <StatsPlayground />
    </section>

    <!-- Fact‑check -->
    <section v-show="tab==='factcheck'" class="rounded-2xl bg-base-100 ring-1 ring-base-300/70 shadow-sm p-5">
      <h2 class="text-xl font-semibold mb-2">Claims & Fact‑Check</h2>
      <ul class="list-disc ml-5 space-y-1 text-sm">
        <li><NuxtLink class="link link-primary" to="/factcheck/ulf-poschardt">Ulf Poschardt — Claims vs Evidence</NuxtLink></li>
      </ul>
    </section>
  </main>
</template>

<script setup lang="ts">
import { onMounted, ref, computed } from 'vue'
import VegaLiteEmbed from '~/components/charts/VegaLiteEmbed.vue'
import StatsPlayground from '~/components/stats/Playground.vue'
import { useInequalityData } from '~/composables/useInequalityData'

const { fetchEurostatTidy, fetchWidTidy } = useInequalityData()

const links = {
  ilc_di12:  'https://ec.europa.eu/eurostat/databrowser/view/ilc_di12/default/table',
  ilc_di11:  'https://ec.europa.eu/eurostat/databrowser/view/ilc_di11/default/table',
  ilc_li02:  'https://ec.europa.eu/eurostat/databrowser/view/ilc_li02/default/table',
  ilc_peps01:'https://ec.europa.eu/eurostat/databrowser/view/ilc_peps01/default/table',
  wid_top10: 'https://wid.world/data',
  wid_top1:  'https://wid.world/data',
  gender_gap:'https://www.destatis.de/EN/Themes/Society-Environment/Earnings/Gender-Pay-Gap/_node.html'
}

const tab = ref<'overview'|'playground'|'factcheck'>('overview')
const loading = ref(false); const errorMsg = ref<string|null>(null)

const giniRows = ref<any[]>([])
const s8020Rows = ref<any[]>([])
const aropRows = ref<any[]>([])
const aropeRows = ref<any[]>([])
const gpgRows = ref<any[]>([])
const widTop10Rows = ref<any[]>([])
const widTop1Rows = ref<any[]>([])

onMounted(async () => {
  loading.value = true; errorMsg.value = null
  try {
    const [gini, s8020, arop, arope] = await Promise.all([
      fetchEurostatTidy({ dataset: 'ilc_di12',  regions: ['DE','EU27_2020'], yearStart: 2010 }),
      fetchEurostatTidy({ dataset: 'ilc_di11',  regions: ['DE','EU27_2020'], yearStart: 2010 }),
      fetchEurostatTidy({ dataset: 'ilc_li02',  regions: ['DE','EU27_2020'], yearStart: 2010 }),
      fetchEurostatTidy({ dataset: 'ilc_peps01',regions: ['DE','EU27_2020'], yearStart: 2010 }),
    ])
    giniRows.value   = gini.rows
    s8020Rows.value  = s8020.rows
    aropRows.value   = arop.rows
    aropeRows.value  = arope.rows

    const top10 = await fetchWidTidy({ series: 'sptinc_p90p100_z', country: 'DE' })
    const top1  = await fetchWidTidy({ series: 'sptinc_p99p100_z', country: 'DE' })
    widTop10Rows.value = top10.rows
    widTop1Rows.value  = top1.rows

    // placeholder for gender pay gap once added:
    gpgRows.value = []
  } catch (e:any) {
    errorMsg.value = e?.message ?? 'Failed loading data'
  } finally {
    loading.value = false
  }
})

/** Chart specs */
const baseLine = (title:string, rows:any)=>({
  $schema:'https://vega.github.io/schema/vega-lite/v5.json',
  description:title,
  data:{ values: rows },
  mark:{ type:'line', point:true, tooltip:true },
  encoding:{
    x:{ field:'year', type:'temporal', title:'Year' },
    y:{ field:'value', type:'quantitative', title:title },
    color:{ field:'region', type:'nominal', title:'Region' }
  },
  width:'container', height:300
})
const giniSpec   = computed(()=> baseLine('Gini (EU‑SILC)', giniRows.value))
const s8020Spec  = computed(()=> baseLine('S80/S20 ratio', s8020Rows.value))
const aropSpec   = computed(()=> baseLine('AROP 60% median', aropRows.value))
const aropeSpec  = computed(()=> baseLine('AROPE', aropeRows.value))
const widTop10Spec = computed(()=> baseLine('Top 10% income share (WID)', widTop10Rows.value))
const widTop1Spec  = computed(()=> baseLine('Top 1% income share (WID)', widTop1Rows.value))
const gpgSpec = computed(()=> baseLine('Gender pay gap (%)', gpgRows.value))
</script>
